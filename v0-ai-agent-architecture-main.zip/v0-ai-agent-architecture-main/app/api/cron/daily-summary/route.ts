import { type NextRequest, NextResponse } from "next/server"
import { createSupabaseServer } from "@/lib/supabase/server"
import { sendWhatsAppMessage } from "@/lib/whatsapp/client"
import { generateText } from "ai"

export async function GET(request: NextRequest) {
  try {
    // Verify cron secret for security
    const authHeader = request.headers.get("authorization")
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const supabase = await createSupabaseServer()

    // Get all active sessions from yesterday
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)
    yesterday.setHours(0, 0, 0, 0)

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const { data: sessions, error: sessionsError } = await supabase
      .from("sessions")
      .select("id, user_id, users(phone, name)")
      .gte("created_at", yesterday.toISOString())
      .lt("created_at", today.toISOString())

    if (sessionsError) {
      throw new Error(`Failed to get sessions: ${sessionsError.message}`)
    }

    let summariesSent = 0

    // Process each session
    for (const session of sessions || []) {
      try {
        // Get messages for this session
        const { data: messages, error: messagesError } = await supabase
          .from("messages")
          .select("role, content, created_at")
          .eq("session_id", session.id)
          .order("created_at", { ascending: true })

        if (messagesError || !messages || messages.length === 0) {
          continue
        }

        // Generate summary using AI
        const conversationText = messages.map((m) => `${m.role}: ${m.content}`).join("\n")

        const { text: summary } = await generateText({
          model: process.env.AI_MODEL || "google/gemini-2.0-flash-exp",
          prompt: `Summarize this conversation in 2-3 sentences:\n\n${conversationText}`,
        })

        // Send summary via WhatsApp
        const userPhone = (session.users as any)?.phone
        if (userPhone) {
          await sendWhatsAppMessage(userPhone, `Daily Summary:\n\n${summary}\n\nThank you for using our service!`)
          summariesSent++
        }
      } catch (error) {
        console.error("[v0] Error processing session:", session.id, error)
      }
    }

    return NextResponse.json({
      success: true,
      summariesSent,
      message: `Sent ${summariesSent} daily summaries`,
    })
  } catch (error) {
    console.error("[v0] Daily summary cron error:", error)
    return NextResponse.json(
      {
        error: "Failed to process daily summaries",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
