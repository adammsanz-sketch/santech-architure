import { type NextRequest, NextResponse } from "next/server"
import { getPendingTasks, updateTaskStatus } from "@/lib/db/tasks"
import { sendWhatsAppMessage } from "@/lib/whatsapp/client"

export async function GET(request: NextRequest) {
  try {
    // Verify cron secret for security
    const authHeader = request.headers.get("authorization")
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const tasks = await getPendingTasks()
    let processedCount = 0

    for (const task of tasks) {
      try {
        // Mark as processing
        await updateTaskStatus(task.id, "processing")

        // Process based on task type
        switch (task.type) {
          case "send_whatsapp":
            if (task.payload?.phone && task.payload?.message) {
              await sendWhatsAppMessage(task.payload.phone, task.payload.message)
            }
            break

          case "generate_report":
            // Add your report generation logic here
            console.log("[v0] Generating report for task:", task.id)
            break

          case "data_processing":
            // Add your data processing logic here
            console.log("[v0] Processing data for task:", task.id)
            break

          default:
            console.log("[v0] Unknown task type:", task.type)
        }

        // Mark as completed
        await updateTaskStatus(task.id, "completed")
        processedCount++
      } catch (error) {
        console.error("[v0] Error processing task:", task.id, error)
        await updateTaskStatus(task.id, "failed")
      }
    }

    return NextResponse.json({
      success: true,
      processedCount,
      message: `Processed ${processedCount} tasks`,
    })
  } catch (error) {
    console.error("[v0] Process tasks cron error:", error)
    return NextResponse.json(
      {
        error: "Failed to process tasks",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
