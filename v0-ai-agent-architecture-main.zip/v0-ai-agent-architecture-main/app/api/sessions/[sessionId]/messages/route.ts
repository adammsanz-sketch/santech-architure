import { type NextRequest, NextResponse } from "next/server"
import { getSessionMessages } from "@/lib/db/messages"

export async function GET(request: NextRequest, { params }: { params: Promise<{ sessionId: string }> }) {
  try {
    const { sessionId } = await params

    if (!sessionId) {
      return NextResponse.json({ error: "Session ID is required" }, { status: 400 })
    }

    const messages = await getSessionMessages(sessionId)

    return NextResponse.json({
      success: true,
      messages,
    })
  } catch (error) {
    console.error("[v0] Get messages error:", error)
    return NextResponse.json(
      { error: "Internal server error", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
