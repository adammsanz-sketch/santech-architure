import { type NextRequest, NextResponse } from "next/server"
import { getOrCreateUser } from "@/lib/db/users"
import { getOrCreateSession } from "@/lib/db/sessions"
import { saveMessage, getSessionMessages } from "@/lib/db/messages"
import { sendWhatsAppMessage } from "@/lib/whatsapp/client"
import { generateText } from "ai"

// GET endpoint for WhatsApp webhook verification
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const mode = searchParams.get("hub.mode")
  const token = searchParams.get("hub.verify_token")
  const challenge = searchParams.get("hub.challenge")

  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN

  if (mode === "subscribe" && token === verifyToken) {
    console.log("[v0] Webhook verified")
    return new NextResponse(challenge, { status: 200 })
  }

  return NextResponse.json({ error: "Verification failed" }, { status: 403 })
}

// POST endpoint for receiving WhatsApp messages
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // WhatsApp webhook structure
    const entry = body.entry?.[0]
    const changes = entry?.changes?.[0]
    const value = changes?.value

    // Check if it's a message
    if (!value?.messages?.[0]) {
      return NextResponse.json({ success: true })
    }

    const message = value.messages[0]
    const from = message.from // Phone number
    const messageText = message.text?.body

    if (!messageText) {
      return NextResponse.json({ success: true })
    }

    console.log("[v0] Received WhatsApp message:", { from, messageText })

    // Get or create user
    const user = await getOrCreateUser(from)

    // Get or create session
    const session = await getOrCreateSession(user.id)

    // Save user message
    await saveMessage(session.id, "user", messageText)

    // Get conversation history
    const messages = await getSessionMessages(session.id)
    const conversationHistory = messages.map((msg) => ({
      role: msg.role as "user" | "assistant" | "system",
      content: msg.content,
    }))

    // Generate AI response
    const { text } = await generateText({
      model: process.env.AI_MODEL || "google/gemini-2.0-flash-exp",
      messages: conversationHistory,
      system: "You are a helpful AI assistant on WhatsApp. Provide clear and concise responses.",
    })

    // Save assistant response
    await saveMessage(session.id, "assistant", text)

    // Send response back via WhatsApp
    await sendWhatsAppMessage(from, text)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Webhook error:", error)
    return NextResponse.json(
      {
        error: "Webhook processing failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
