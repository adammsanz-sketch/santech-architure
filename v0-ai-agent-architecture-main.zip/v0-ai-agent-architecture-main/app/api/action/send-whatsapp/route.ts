import { type NextRequest, NextResponse } from "next/server"
import { sendWhatsAppMessage } from "@/lib/whatsapp/client"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, message } = body

    // Validate input
    if (!phone || !message) {
      return NextResponse.json({ error: "Phone and message are required" }, { status: 400 })
    }

    // Send WhatsApp message
    await sendWhatsAppMessage(phone, message)

    return NextResponse.json({
      success: true,
      message: "WhatsApp message sent successfully",
    })
  } catch (error) {
    console.error("[v0] Send WhatsApp error:", error)
    return NextResponse.json(
      {
        error: "Failed to send WhatsApp message",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
