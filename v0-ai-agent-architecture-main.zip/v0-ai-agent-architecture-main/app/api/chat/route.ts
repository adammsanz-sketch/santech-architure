import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { getOrCreateUser } from "@/lib/db/users"
import { getOrCreateSession } from "@/lib/db/sessions"
import { saveMessage, getSessionMessages } from "@/lib/db/messages"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, message, name } = body

    // Validate input
    if (!phone || !message) {
      return NextResponse.json({ error: "Phone and message are required" }, { status: 400 })
    }

    // Get or create user
    const user = await getOrCreateUser(phone, name)

    // Get or create active session
    const session = await getOrCreateSession(user.id)

    // Save user message
    await saveMessage(session.id, "user", message)

    // Get conversation history
    const messages = await getSessionMessages(session.id)
    const conversationHistory = messages.map((msg) => ({
      role: msg.role as "user" | "assistant" | "system",
      content: msg.content,
    }))

    const { text } = await generateText({
      model: process.env.AI_MODEL || "google/gemini-2.0-flash-exp",
      messages: conversationHistory,
      system: "You are a helpful AI assistant. Provide clear and concise responses.",
    })

    // Save assistant response
    await saveMessage(session.id, "assistant", text)

    return NextResponse.json({
      success: true,
      response: text,
      session_id: session.id,
    })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return NextResponse.json(
      { error: "Internal server error", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
