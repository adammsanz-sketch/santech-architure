import { ChatInterface } from "@/components/chat-interface"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">AI Agent Chat</h1>
        <p className="text-muted-foreground">Test your AI agent by sending messages</p>
      </div>
      <div className="flex-1">
        <ChatInterface />
      </div>
    </main>
  )
}
