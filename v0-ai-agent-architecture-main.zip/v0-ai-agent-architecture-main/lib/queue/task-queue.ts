import { createTask } from "@/lib/db/tasks"

export async function queueWhatsAppMessage(sessionId: string, phone: string, message: string) {
  return createTask(sessionId, "send_whatsapp", { phone, message })
}

export async function queueReportGeneration(sessionId: string, reportType: string, params?: Record<string, any>) {
  return createTask(sessionId, "generate_report", { reportType, ...params })
}

export async function queueDataProcessing(sessionId: string, dataType: string, data: any) {
  return createTask(sessionId, "data_processing", { dataType, data })
}
