export interface User {
  id: string
  phone: string
  name?: string
  created_at: string
}

export interface Session {
  id: string
  user_id: string
  status: "active" | "closed"
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  session_id: string
  role: "user" | "assistant" | "system"
  content: string
  created_at: string
}

export interface Task {
  id: string
  session_id: string
  type: string
  status: "pending" | "processing" | "completed" | "failed"
  payload?: Record<string, any>
  created_at: string
  updated_at: string
}
