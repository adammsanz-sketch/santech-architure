interface WhatsAppMessage {
  messaging_product: string
  to: string
  type: string
  text: {
    body: string
  }
}

export async function sendWhatsAppMessage(to: string, message: string): Promise<boolean> {
  const whatsappApiUrl = `https://graph.facebook.com/v18.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`
  const accessToken = process.env.WHATSAPP_ACCESS_TOKEN

  if (!accessToken || !process.env.WHATSAPP_PHONE_NUMBER_ID) {
    throw new Error("WhatsApp credentials not configured")
  }

  const payload: WhatsAppMessage = {
    messaging_product: "whatsapp",
    to: to,
    type: "text",
    text: {
      body: message,
    },
  }

  try {
    const response = await fetch(whatsappApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const error = await response.text()
      throw new Error(`WhatsApp API error: ${error}`)
    }

    return true
  } catch (error) {
    console.error("[v0] WhatsApp send error:", error)
    throw error
  }
}
