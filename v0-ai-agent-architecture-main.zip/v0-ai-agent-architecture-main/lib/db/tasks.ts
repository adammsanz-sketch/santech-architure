import { createSupabaseServer } from "@/lib/supabase/server"
import type { Task } from "@/lib/types"

export async function createTask(sessionId: string, type: string, payload?: Record<string, any>): Promise<Task> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("tasks")
    .insert({
      session_id: sessionId,
      type,
      status: "pending",
      payload,
    })
    .select()
    .single()

  if (error) {
    throw new Error(`Failed to create task: ${error.message}`)
  }

  return data
}

export async function updateTaskStatus(
  taskId: string,
  status: "pending" | "processing" | "completed" | "failed",
): Promise<Task> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase.from("tasks").update({ status }).eq("id", taskId).select().single()

  if (error) {
    throw new Error(`Failed to update task: ${error.message}`)
  }

  return data
}

export async function getPendingTasks(): Promise<Task[]> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("tasks")
    .select("*")
    .eq("status", "pending")
    .order("created_at", { ascending: true })

  if (error) {
    throw new Error(`Failed to get pending tasks: ${error.message}`)
  }

  return data || []
}
