import { createSupabaseServer } from "@/lib/supabase/server"
import type { Message } from "@/lib/types"

export async function saveMessage(
  sessionId: string,
  role: "user" | "assistant" | "system",
  content: string,
): Promise<Message> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("messages")
    .insert({ session_id: sessionId, role, content })
    .select()
    .single()

  if (error) {
    throw new Error(`Failed to save message: ${error.message}`)
  }

  return data
}

export async function getSessionMessages(sessionId: string): Promise<Message[]> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: true })

  if (error) {
    throw new Error(`Failed to get messages: ${error.message}`)
  }

  return data || []
}
