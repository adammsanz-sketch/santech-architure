import { createSupabaseServer } from "@/lib/supabase/server"
import type { Session } from "@/lib/types"

export async function getActiveSession(userId: string): Promise<Session | null> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("sessions")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(1)
    .single()

  if (error && error.code !== "PGRST116") {
    throw new Error(`Failed to get session: ${error.message}`)
  }

  return data
}

export async function createSession(userId: string): Promise<Session> {
  const supabase = await createSupabaseServer()

  const { data, error } = await supabase
    .from("sessions")
    .insert({ user_id: userId, status: "active" })
    .select()
    .single()

  if (error) {
    throw new Error(`Failed to create session: ${error.message}`)
  }

  return data
}

export async function getOrCreateSession(userId: string): Promise<Session> {
  const activeSession = await getActiveSession(userId)
  if (activeSession) {
    return activeSession
  }
  return createSession(userId)
}
