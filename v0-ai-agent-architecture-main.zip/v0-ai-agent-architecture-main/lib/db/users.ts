import { createSupabaseServer } from "@/lib/supabase/server"
import type { User } from "@/lib/types"

export async function getOrCreateUser(phone: string, name?: string): Promise<User> {
  const supabase = await createSupabaseServer()

  // Try to get existing user
  const { data: existingUser, error: fetchError } = await supabase.from("users").select("*").eq("phone", phone).single()

  if (existingUser && !fetchError) {
    return existingUser
  }

  // Create new user
  const { data: newUser, error: createError } = await supabase.from("users").insert({ phone, name }).select().single()

  if (createError) {
    throw new Error(`Failed to create user: ${createError.message}`)
  }

  return newUser
}
